import java.time.LocalDate;

public abstract class EducationCenter {
    //name,                имя,
    //located              местонахождение
    //Country              Страна
    //Local                Местная дата
    //foundation Year;     Год основания
    private String name;
    private String located;
    private String country;
    private LocalDate local;

    public EducationCenter(String name, String located, String country, LocalDate local) {
        this.name = name;
        this.located = located;
        this.country = country;
        this.local = local;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocated() {
        return located;
    }

    public void setLocated(String located) {
        this.located = located;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public LocalDate getLocal() {
        return local;
    }

    public void setLocal(LocalDate local) {
        this.local = local;
    }
}
