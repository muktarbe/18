public interface Study {
    void getStudentsEducationCenter();
    void getStudentsStudyingYear();
}
