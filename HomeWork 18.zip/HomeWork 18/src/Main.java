import java.time.LocalDate;
import java.time.Period;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        EducationCenter educationCenter1 = new School(" музыкальная школа ", " Бишкек ", " Кыргыстан ", LocalDate.of(2003, 6, 12));
        EducationCenter educationCenter2 = new University(" Исаев ", " Токмок ", " Кыргыстан ", LocalDate.of(2005, 8, 2));
        EducationCenter educationCenter3 = new University(" Ибраимов ", " Талас ", " Кыргыстан ", LocalDate.of(2002, 10, 23));
        Student[] student = {
                new Student(" Залкарбек ", " Маманов ", " мальчик ", educationCenter1, LocalDate.of(2006, 9, 23)),
                new Student(" Кандыбек ", " Исаев ", " мальчик ", educationCenter1, LocalDate.of(2006, 9, 23)),
                new Student(" Билал ", " Акылбеков ", " мальчик ", educationCenter1, LocalDate.of(2006, 9, 23)),
                new Student(" Билал ", " Шарапав ", " мальчик ", educationCenter2, LocalDate.of(2006, 9, 23)),
                new Student(" Рамазан ", " Каракэев ", " мальчик ", educationCenter2, LocalDate.of(2006, 9, 23)),
                new Student(" Зафар ", " Раимбердиев ", " мальчик ", educationCenter2, LocalDate.of(2006, 9, 23)),
                new Student(" Алина  ", " Ахунова ", " девочка ", educationCenter3, LocalDate.of(2006, 9, 23)),
                new Student(" Тунук ", " Жумабекова ", " девочка ", educationCenter3, LocalDate.of(2006, 9, 23)),
                new Student(" уулкелсин ", " Нурдинова ", " девочка ", educationCenter3, LocalDate.of(2006, 9, 23)),
                new Student(" Аделия ", " Жылдызбекова ", " девочка ", educationCenter1, LocalDate.of(2006, 9, 23))
        };
        printStudentInfo(student);
    }

    public static void printStudentInfo(Student[] students) {
        for (Student s : students) {
            System.out.println("Имя: " + s.getName() + " " + s.getSurname());
            System.out.println("Пол: " + s.getGender());
            System.out.println("Образовательное учреждение: " + s.getEducationCenter().getName());
            System.out.println("Страна: " + s.getEducationCenter().getCountry());
            System.out.println("Дата поступления: " + s.getLocalDate());

            LocalDate currentDate = LocalDate.now();
            Period period = Period.between(s.getLocalDate(), currentDate);
            System.out.println("Прошло времени с поступления: " + period.getYears() + " лет, " +
                    period.getMonths() + " месяцев, " + period.getDays() + " дней");

            System.out.println(); // Пустая строка между записями
        }
    }
}

