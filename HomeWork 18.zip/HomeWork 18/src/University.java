import java.time.LocalDate;

public class University extends EducationCenter{
    public University(String name, String located, String country, LocalDate local) {
        super(name, located, country, local);
    }
}
