import java.time.LocalDate;

public class School extends EducationCenter{
    public School(String name, String located, String country, LocalDate local) {
        super(name, located, country, local);
    }
}
